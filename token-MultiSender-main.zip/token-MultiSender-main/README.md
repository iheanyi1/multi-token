# Token MultiSender aka Bee-Sender-v2
Token MultiSender - Transfer token to 500 wallets in one transaction and save your cost.<br>

``Batch Send Token``<br>
``Batch Send ETH/BNB/Matic...``<br>
Current support Blockchain networks:<br>
Ethereum,Binance,Huobi,Fantom,Polygon,Avalanche,Cronos,Moonbeam,Moonriver.<br><br>
<img src="img/1.png" width="25" height="25" alt="eth"> 
<img src="img/56.png" width="25" height="25" alt="bnb">
<img src="img/250.png" width="25" height="25" alt="ftm">
<img src="img/137.png" width="25" height="25" alt="matic"> 
<img src="img/43114.png" width="25" height="25" alt="matic">
<img src="img/25.png" width="25" height="25" alt="matic">
<img src="img/13381.png" width="25" height="25" alt="matic">
<img src="img/534.png" width="25" height="25" alt="matic">
<img src="img/1284.png" width="25" height="25" alt="moonbeam">
<img src="img/1285.png" width="25" height="25" alt="moonriver">
<br>
V2 add features:<br>
1.Sending tokens with decimal points is now supported,like:1.01,2.3,33 is accept.<br>
2.Supports importing addresses and sending quantities using CSV files.<br>
3.If you want to fork Token MultiSender to earn cryptocurrency, version 2 removes the fee limit, and now you can customize the user fee. High or low is up to you.<br>
4.upgrade GUI.<br>
5.add Ethereum network.<br>

Send addresses once:<br>
1-500<br>

<img src="screen.png" alt="erc20-tokens-multi-sender">

Site:
https://token-multi-sender.vercel.app/


# Need Earn cryptocurrency?
Open js/config.js<br>
Change the address to your own address,customize fee you will recieve.<br>


# Deploy to github page

or you can download source ,and put to any web server.then start earn cryptocurrency!<br>

# You can deployed this source to any server and change the brand name without my approve.

<br>
Update:<br>
Version 2.1:Fix bug,add multi language.<br>
Version 2.2:Add moonriver,moonbeam<br>
 
 

