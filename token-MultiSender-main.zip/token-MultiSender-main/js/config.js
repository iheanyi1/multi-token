//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// 1.change this address to your own address
// 2.set how much fee you will recieve,for example:0.01 
// 3.client total fee= contract small fee + your setting fee
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

var FeeReciever = "0x30B293f385D23dDdb3FdcDd5D0e90820869DA427";


var BinanceFee=0.005;
var PolygonFee=0.1;
var FantomFee=0.1;
var RopstenFee=0.00001;
var HuobiFee=0.01;
var AvalancheFee=0.1;
var EthereumFee=0.01;
var CronosFee=3;
var PhoenixFee=0.1;
var CandleFee=1; 
var MoonbeamFee=1;
var MoonriverFee=0.05;
